<?php
// Include database connection code
include_once "connection.php"; // Adjust this to your database connection file

// Debugging: Check the GET parameters
var_dump($_GET);

// Check if permit_id is provided via GET method
if (isset($_GET['permit_id'])) {
    $permit_id = $_GET['permit_id'];

    // Debugging: Output the captured permit_id
    echo "Permit ID captured: $permit_id<br>";

    // Query to fetch permit details based on permit_id
    $select_permit_sql = "SELECT * FROM Permits WHERE permit_id = $permit_id";
    $result_permit = mysqli_query($conn, $select_permit_sql);

    if ($row_permit = mysqli_fetch_assoc($result_permit)) {
        // Debugging: Output the fetched permit details
        echo "Permit Details:<br>";
        echo "Permit Type: " . $row_permit['permit_type'] . "<br>";
        echo "Permit Number: " . $row_permit['permit_number'] . "<br>";
        echo "Issue Date: " . $row_permit['issue_date'] . "<br>";
        echo "Expiry Date: " . $row_permit['expiry_date'] . "<br>";
        echo "Status: " . $row_permit['status'] . "<br>";

        // Handle form submission to update permit status
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $new_status = $_POST['status'];

            // Update status in the Permits table
            $update_permit_sql = "UPDATE Permits SET status = '$new_status' WHERE permit_id = $permit_id";

            // Update status in the Documents table
            $update_documents_sql = "UPDATE Documents SET status = '$new_status' WHERE permit_id = $permit_id";

            // Execute both queries
            if (mysqli_query($conn, $update_permit_sql) && mysqli_query($conn, $update_documents_sql)) {
                echo '<script>alert("Status updated successfully.");</script>';
                // Redirect to a different page or refresh the current page
                echo '<script>window.location.replace("some_other_page.php");</script>';
                exit;
            } else {
                echo '<script>alert("Error updating status: ' . mysqli_error($conn) . '");</script>';
            }
        }
    } else {
        echo "Permit not found.";
    }
} else {
    echo "Permit ID not provided.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Status</title>
</head>

<body>
    <h1>Update Status</h1>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="hidden" name="permit_id" value="<?php echo $permit_id; ?>">
        <label for="status">Status:</label>
        <select id="status" name="status">
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
        </select>
        <br><br>
        <input type="submit" value="Update Status">
    </form>
</body>

</html>
