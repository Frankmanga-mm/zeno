<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="../css/login.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
</head>

<body>
    <div class="login-container">
        <form id="loginForm" method="POST">
            <div class="input-group">
                <span class="icon"><i class="fas fa-envelope"></i></span>
                <input type="email" id="email" name="email" placeholder="Email">
            </div>
            <div class="input-group">
                <span class="icon"><i class="fas fa-lock"></i></span>
                <input type="password" id="password" name="password" placeholder="Password">
            </div>
            <div class="links">
                <div>Don't have an account? <a href="register.php">Sign Up</a></div>
                <div><a href="forgot_password.php">Forgot Password</a></div>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>
</body>

</html>

<?php
// Start the session
session_start();

// Include database connection code
include_once "connection.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize inputs (optional but recommended)
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    // Hash the password (assuming password_hash column stores hashed passwords)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if the email and hashed password match in the database
    $sql = "SELECT user_id, email, password_hash, role FROM Users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password_hash'])) {
            // Password is correct, set session variables
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['role'] = $row['role'];

            // Redirect based on user role
            switch ($row['role']) {
                case 'user':
                    header("Location: user_dashboard.php");
                    break;
                case 'owner':
                    header("Location: owner_dashboard.php");
                    break;
                case 'builder':
                    header("Location: builder_dashboard.php");
                    break;
                case 'authority':
                    header("Location: authority_dashboard.php");
                    break;
                default:
                    // Redirect to a default page if role is not recognized
                    header("Location: login.php.php");
                    break;
            }
            exit();
        } else {
            // Incorrect password
            $error = "Invalid password. Please try again.";
        }
    } else {
        // Email not found
        $error = "Email not found. Please register.";
    }
}
?>



