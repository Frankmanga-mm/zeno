<?php
include_once "connection.php";
session_start(); // Start or resume session

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate form data
    $owner_name = filter_var($_POST['owner_name'], FILTER_SANITIZE_STRING);
    $area_name = filter_var($_POST['area_name'], FILTER_SANITIZE_STRING);
    $contact_number = filter_var($_POST['contact_number'], FILTER_SANITIZE_NUMBER_INT);
    $address = filter_var($_POST['address'], FILTER_SANITIZE_STRING);
    $registration_date = filter_var($_POST['registration_date'], FILTER_SANITIZE_STRING);

    // Check if the user is logged in
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];

        // Insert data into Owners table with user_id
        $insert_sql = "INSERT INTO Owners (user_id, owner_name, area_name, contact_number, address, registration_date) 
                        VALUES ('$user_id', '$owner_name', '$area_name', '$contact_number', '$address', '$registration_date')";

        if (mysqli_query($conn, $insert_sql)) {
            // Redirect after successful registration
            echo"Owner registration success fully";
            exit(); // Make sure to exit after redirecting
        } else {
            echo "Error: " . $insert_sql . "<br>" . mysqli_error($conn);
            // Handle the error as needed
        }
    } else {
        // Redirect to login page
        echo"registration failed ";
        exit(); // Make sure to exit after redirecting
    }

    // Close database connection if necessary
    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Owner Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }

        .registration-form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .form-group textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .form-group .icon {
            position: absolute;
            margin-left: -30px;
            line-height: 40px;
            cursor: pointer;
        }

        .form-group .icon i {
            color: #999;
        }

        .btn-submit {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="registration-form">
        <h2>Owner Registration</h2>
        <form  method="POST">
            <div class="form-group">
                <label for="owner_name">Owner Name</label>
                <input type="text" id="owner_name" name="owner_name" required>
                <span class="icon"><i class="fas fa-user"></i></span>
            </div>
            <div class="form-group">
                <label for="area_name">Area Name</label>
                <input type="text" id="area_name" name="area_name" required>
                <span class="icon"><i class="fas fa-map-marker-alt"></i></span>
            </div>
            <div class="form-group">
                <label for="contact_number">Contact Number</label>
                <input type="text" id="contact_number" name="contact_number" required>
                <span class="icon"><i class="fas fa-phone"></i></span>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" rows="4" required></textarea>
                <span class="icon"><i class="fas fa-address-card"></i></span>
            </div>
            <div class="form-group">
                <label for="registration_date">Registration Date</label>
                <input type="text" id="registration_date" name="registration_date" required readonly>
                <span class="icon icon-calendar"><i class="fas fa-calendar-alt"></i></span>
            </div>
            <button type="submit" class="btn-submit">Register</button>
        </form>
    </div>

    <!-- Include jQuery and jQuery UI libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <script>
        $(function() {
            // Initialize datepicker
            $("#registration_date").datepicker({
                dateFormat: "yy-mm-dd", // Format the date as YYYY-MM-DD
                changeMonth: true,
                changeYear: true,
                yearRange: "-100:+0" // Allow selection of years up to 100 years ago from the current year
            });

            // Handle click event on calendar icon to show datepicker
            $(".icon-calendar").on("click", function() {
                $("#registration_date").datepicker("show");
            });
        });
    </script>
</body>

</html>
