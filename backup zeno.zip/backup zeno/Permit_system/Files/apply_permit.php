<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Permit</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }

        .permit-form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="file"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .form-group select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .required-icon::before {
            content: '*';
            color: red;
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
        }

        .btn-submit {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="permit-form">
        <h2>Apply for Permit</h2>
        <form  method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="document_name" class="required-icon">Document description</label>
                <input type="text" id="document_name" name="document_name" required>
            </div>
            <div class="form-group">
                <label for="document_type" class="required-icon">Select document Type</label>
                <select id="document_type" name="document_type" required>
                    <option value=""></option>
                    <option value="Building Permit">Building Permit</option>
                    <option value="Environmental Permit">Environmental Permit</option>
                    <option value="Zoning Permit">Zoning Permit</option>
                    <!-- Add more options as needed -->
                </select>
            </div>
            <div class="form-group">
                <label for="upload_file" class="required-icon">Upload Document</label>
                <input type="file" id="upload_file" name="upload_file" accept=".pdf,.doc,.docx,.txt" required>
            </div>
            <button type="submit" class="btn-submit">Submit</button>
        </form>
    </div>
</body>

</html>
<?php
// Start session
session_start();

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {

    // Get the logged-in user's user_id from the session
    $user_id = $_SESSION['user_id'];
    $ownerId = $_SESSION['owner_id'];

    // Include database connection code
    include_once "connection.php"; // Adjust this to your database connection file

    // Query to select owner_id based on user_id
    $select_owner_id_sql = "SELECT owner_id FROM Owners WHERE user_id = $user_id";

    // Execute the query
    $result = mysqli_query($conn, $select_owner_id_sql);

    // Check if the query was successful
    if ($result) {
        // Fetch the owner_id
        $row = mysqli_fetch_assoc($result);
        $owner_id = $row['owner_id'];

        // Check if a file is uploaded
        if (isset($_FILES['upload_file'])) {
            $file_name = $_FILES['upload_file']['name'];
            $file_tmp = $_FILES['upload_file']['tmp_name'];

            // Specify the directory where you want to move the uploaded file
            $upload_directory = "../uploads";

            // Move the uploaded file to the specified directory
            if (move_uploaded_file($file_tmp, $upload_directory . $file_name)) {
                // File uploaded successfully, now insert into Document table
                $document_name = $_POST['document_name'];
                $document_type = $_POST['document_type'];
                $upload_date = date("Y-m-d H:i:s");
                $file_path = $upload_directory . $file_name;

                // Insert data into Document table
                $insert_document_sql = "INSERT INTO Documents (owner_id, document_name, document_type, upload_date, file_path) 
                                        VALUES ('$owner_id', '$document_name', '$document_type', '$upload_date', '$file_path')";

                // Execute the insertion query
                if (mysqli_query($conn, $insert_document_sql)) {
                    echo "Document inserted successfully!";
                } else {
                    echo "Error inserting document: " . mysqli_error($conn);
                    // Handle the error as needed
                }
            } else {
                echo "Error uploading file.";
                // Handle the upload error as needed
            }
        } else {
            echo "No file uploaded.";
            // Handle the case where no file is uploaded
        }
    } else {
        echo "Error selecting owner ID: " . mysqli_error($conn);
        // Handle the error as needed
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    echo "User not logged in.";
    // Redirect or display a message indicating that the user is not logged in
}
?>
