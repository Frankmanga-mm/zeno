<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .dashboard-header {
            text-align: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px 0;
            margin-bottom: 20px;
        }

        #dashboard-content {
            display: flex;
            justify-content: space-between;
            padding: 20px;
        }

        .dashboard-column {
            flex: 0 0 48%; /* Set the width of each column */
        }

        .dashboard-link {
            display: block;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
        }

        .dashboard-link:hover {
            background-color: #e0e0e0;
        }

        .dashboard-link i {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="dashboard-header">
        <h1>Dashboard</h1>
    </div>
    <div id="dashboard-content">
        <div class="dashboard-column">
            <!-- Left Column Content -->
            <!-- Account management -->
            <a href="owner_details_registration.php" class="dashboard-link"><i class="fas fa-user-plus"></i> Owner Details Registration</a>
            <a href="apply_permit.php" class="dashboard-link"><i class="fas fa-file-signature"></i> Apply Permit</a>
            <a href="user_profile.php" class="dashboard-link"><i class="fas fa-user"></i> Profile</a>
            <a href="change_password.php" class="dashboard-link"><i class="fas fa-lock"></i> Change Password</a>
            <!-- View notifications and alerts -->
            <a href="notifications.php" class="dashboard-link"><i class="fas fa-bell"></i> View Notifications</a>
        </div>
        <div class="dashboard-column">
            <!-- Right Column Content -->
            <!-- Access help or support -->
            <a href="user_update.php" class="dashboard-link"><i class="fas fa-plus-circle"></i>Update Your details</a>
            <!-- View project status -->
            <a href="status.php" class="dashboard-link"><i class="fas fa-chart-bar"></i>Status</a>
            <!-- Access documents and permits -->
            <a href="view_documents.php" class="dashboard-link"><i class="fas fa-file-alt"></i> View Documents</a>
            <a href="Print_permits.php" class="dashboard-link"><i class="fas fa-stamp"></i> Print Permits</a>
            <!-- Logout -->
            <a href="logout.php" class="dashboard-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
</body>

</html>
