<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Builder Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        #dashboard-content {
            padding: 20px;
        }

        .dashboard-link {
            display: block;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
        }

        .dashboard-link:hover {
            background-color: #e0e0e0;
        }

        .dashboard-link i {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div id="dashboard-content">
        <h1>Builder Dashboard</h1>
        <!-- View projects -->
        <a href="view_assigned_projects.php" class="dashboard-link"><i class="fas fa-tasks"></i> View Assigned Projects</a>
        <!-- Access documents and permits -->
        <a href="view_assigned_documents.php" class="dashboard-link"><i class="fas fa-file-alt"></i> View Assigned Documents</a>
        <a href="view_assigned_permits.php" class="dashboard-link"><i class="fas fa-stamp"></i> View Assigned Permits</a>
        <!-- Manage tasks and progress -->
        <a href="manage_tasks.php" class="dashboard-link"><i class="fas fa-tasks"></i> Manage Tasks</a>
        <a href="update_progress.php" class="dashboard-link"><i class="fas fa-chart-line"></i> Update Progress</a>
        <!-- Communication -->
        <a href="communicate.php" class="dashboard-link"><i class="fas fa-comments"></i> Communicate</a>
        <!-- Logout -->
        <a href="logout.php" class="dashboard-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</body>
</html>
