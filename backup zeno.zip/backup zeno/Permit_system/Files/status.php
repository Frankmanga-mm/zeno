<?php
// Start a PHP session
session_start();

// Include the database connection file
include 'connection.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Retrieve data from the Owners and Documents tables
    $query = "SELECT o.owner_name, d.status
              FROM Owners o
              LEFT JOIN Documents d ON o.owner_id = d.owner_id
              WHERE o.user_id = $userId"; // Use the session user ID

    $result = mysqli_query($conn, $query);

    // Check if the query was successful
    if ($result) {
        // Check if any rows were returned
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $ownerName = $row['owner_name']; // Retrieve owner's name
            $status = $row['status']; // Retrieve the status from Documents table
        } else {
            $errorMessage = "No data found for the user.";
        }
    } else {
        // Handle the error if the query fails
        $errorMessage = "Error fetching data: " . mysqli_error($conn);
    }
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
</head>
<body>
    <h1>User Profile</h1>
    <?php if (isset($errorMessage)) : ?>
        <p><?php echo $errorMessage; ?></p>
    <?php else : ?>
        <p><strong>Owner Name:</strong> <?php echo $ownerName; ?></p>
        <p><strong>Permit Status:</strong> <?php echo $status; ?></p> <!-- Display Permit Status -->
    <?php endif; ?>
</body>
</html>
