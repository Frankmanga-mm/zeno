<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Registration</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="../css/register.css">

</head>
<body>

<div class="container">
    <h2>User Registration</h2>
    <form  method="POST">
        <div class="form-group">
            <label for="username">Full name</label>
            <div class="icon">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" required>
            </div>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <div class="icon">
                <i class="fas fa-envelope"></i>
                <input type="email" id="email" name="email" required>
            </div>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <div class="icon">
                <i class="fas fa-lock"></i>
                <input type="password" id="password" name="password" required>
                <span class="toggle-password" onclick="togglePassword('password')">
                    <i class="fas fa-eye"></i>
                </span>
            </div>
        </div>
        <div class="form-group">
            <label for="confirm-password">Confirm Password:</label>
            <div class="icon">
                <i class="fas fa-lock"></i>
                <input type="password" id="confirm-password" name="confirm-password" required>
                <span class="toggle-password" onclick="togglePassword('confirm-password')">
                    <i class="fas fa-eye"></i>
                </span>
            </div>
        </div>
        <button type="submit" class="btn">Register</button>
    </form>
</div>

<script>
    function togglePassword(inputId) {
        const input = document.getElementById(inputId);
        input.type = input.type === 'password' ? 'text' : 'password';
    }
</script>

</body>
</html>

<?php
error_reporting(0);
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "_permit_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitizeInput($conn, $data) {
    $data = mysqli_real_escape_string($conn, $data);
    return $data;
}

// Function to hash the password
function hashPassword($password) {
    // Add salt or use stronger hashing methods for production
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    return $hashedPassword;
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = sanitizeInput($conn, $_POST["username"]);
    $email = sanitizeInput($conn, $_POST["email"]);
    $rawPassword = $_POST["password"];
    $role = sanitizeInput($conn, $_POST["role"]);
    $confirmPassword = $_POST["confirm-password"];

    // Check if password matches confirm password
    if ($rawPassword !== $confirmPassword) {
        echo "Error: Password and Confirm Password do not match.";
    } else {
        // Validate password complexity
        if (preg_match('/^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])[A-Za-z\d@#$%^&*!]{6,}$/', $rawPassword)) {
            $password_hash = hashPassword($rawPassword);

            // Check if email already exists
            $checkEmailQuery = "SELECT * FROM Users WHERE email = '$email'";
            $result = $conn->query($checkEmailQuery);

            if ($result->num_rows > 0) {
                echo "Error: Email already exists.";
            } else {
                // Prepare and execute SQL statement to insert new user
                $stmt = $conn->prepare("INSERT INTO Users (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $username, $email, $password_hash, $role);
                
                if ($stmt->execute()) {
                    echo "New record inserted successfully";
                    Header("location:login.php");
                } else {
                    echo "Error: " . $stmt->error;
                }

                $stmt->close();
            }
        } else {
            echo "Error: Password must have at least one digit, one uppercase letter, one lowercase letter, and be at least 6 characters long.";
        }
    }

    // Close connection
    $conn->close();
}
?>
