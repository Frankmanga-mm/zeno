<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Owner Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        #dashboard-content {
            padding: 20px;
        }

        .dashboard-link {
            display: block;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
        }

        .dashboard-link:hover {
            background-color: #e0e0e0;
        }

        .dashboard-link i {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div id="dashboard-content">
        <h1>Owner Dashboard</h1>
        <!-- Manage projects -->
        <a href="create_project.php" class="dashboard-link"><i class="fas fa-plus-circle"></i> Create Project</a>
        <!-- Apply permit -->
        <a href="apply_permit.php" class="dashboard-link"><i class="fas fa-file-signature"></i> Apply Permit</a>
        <a href="update_project.php" class="dashboard-link"><i class="fas fa-edit"></i> Update Project</a>
        <a href="assign_roles.php" class="dashboard-link"><i class="fas fa-user-tag"></i> Assign Roles</a>
        <!-- View project status -->
        <a href="project_status.php" class="dashboard-link"><i class="fas fa-chart-bar"></i> Project Status</a>
        <!-- Access documents and permits -->
        <a href="view_documents.php" class="dashboard-link"><i class="fas fa-file-alt"></i> View Documents</a>
        <a href="manage_permits.php" class="dashboard-link"><i class="fas fa-stamp"></i> Manage Permits</a>
        <!-- Manage project timelines -->
        <a href="manage_timelines.php" class="dashboard-link"><i class="fas fa-calendar-alt"></i> Manage Timelines</a>
        <!-- Communication -->
        <a href="communicate.php" class="dashboard-link"><i class="fas fa-comments"></i> Communicate</a>
        
        <!-- Logout -->
        <a href="logout.php" class="dashboard-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</body>
</html>
