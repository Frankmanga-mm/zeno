<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Permit Application Details</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 20px 0; /* Margin added to the top and bottom */
            padding: 0;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 60vh;
        }

        .permit-details {
            max-width: 800px;
            padding: 0px;
        }

        .permit {
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
        }

        .owner-details h2,
        .document-details h2 {
            margin-bottom: 2px;
        }

        .owner-details ul,
        .document-details ul {
            list-style-type: none;
            padding: 0;
        }

        .owner-details ul li,
        .document-details ul li {
            margin-bottom: 5px;
        }

        .owner-details ul li strong,
        .document-details ul li strong {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="permit-details">
            <h1>Permit Application Details</h1>
        </div>
    </div>
</body>

</html>


<?php
session_start();
error_reporting(0);

// Include database connection code
include_once "connection.php"; // Adjust this to your database connection file


$ownerId = $_SESSION['owner_id'];

// Query to fetch permit application details from Owners and Documents tables
$select_details_sql = "SELECT o.owner_id, o.owner_name, o.area_name, o.contact_number, o.address, o.registration_date, 
                                d.document_name, d.document_type
                        FROM Owners o
                        JOIN Documents d ON o.owner_id = d.owner_id";

// Execute the query
$result = mysqli_query($conn, $select_details_sql);

// Check if there are rows returned
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Display owner details for each permit application
        echo '<div class="permit">';
        echo '<div class="owner-details">';
        echo '<h2>Owner Details</h2>';
        echo '<ul>';
        echo '<li><strong>Owner Name</strong> ' . $row['owner_name'] . '</li>';
        echo '<li><strong>Area Name</strong> ' . $row['area_name'] . '</li>';
        echo '<li><strong>Contact Number</strong> ' . $row['contact_number'] . '</li>';
        echo '<li><strong>Address:</strong> ' . $row['address'] . '</li>';
        echo '<li><strong>Registration Date</strong> ' . $row['registration_date'] . '</li>';
        echo '</ul>';
        echo '</div>';

        // Display document details for each permit application
        echo '<div class="document-details">';
        echo '<h2>Document Details</h2>';
        echo '<ul>';
        echo '<li><strong>Document Description</strong> ' . $row['document_name'] . '</li>';
        echo '<li><strong>Document Type</strong> ' . $row['document_type'] . '</li>';
        echo '</ul>';
        echo '</div>';

        // Create the permit link
        echo '<div class="permit-link">';
        echo '<a href="permit.php?owner_id=' . $row['owner_id'] . '">Permit</a>'; // Modify the URL as needed
        echo '</div>';

        echo '</div>';
    }
} else {
    echo "No permit application details found.";
}

// Close the database connection
mysqli_close($conn);
?>