<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/register.css">
</head>
<body>

<div class="container">
    <h2>Update User Details</h2>
    <form method="POST">
        <div class="form-group">
            <label for="username">Full name</label>
            <div class="icon">
                <i class="fas fa-user"></i>
                <input type="text" id="username" name="username" value="<?php echo $username ?>" required>
            </div>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <div class="icon">
                <i class="fas fa-envelope"></i>
                <input type="email" id="email" name="email" value="<?php echo $email ?>" required>
            </div>
        </div>
        <!-- Other form fields for password, etc., with pre-filled values -->
        <button type="submit" class="btn" name="update">Update</button>
    </form>
</div>

</body>
</html>
<?php
// Your database connection and functions here
include 'connection.php';
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = sanitizeInput($conn, $_GET['id']);

    // Fetch user details by ID
    $fetchUserQuery = "SELECT * FROM Users WHERE id = '$id'";
    $result = $conn->query($fetchUserQuery);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $username = $row['username'];
        $email = $row['email']; // Fetching email from the database
        // Fetch other user details as needed
    } else {
        echo "Error: User not found.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $id = sanitizeInput($conn, $_POST['id']);
    $newUsername = sanitizeInput($conn, $_POST['username']);
    $newEmail = sanitizeInput($conn, $_POST['email']);

    // Prepare and execute SQL statement to update user details
    $updateUserQuery = "UPDATE Users SET username = '$newUsername', email = '$newEmail' WHERE id = '$id'";

    if ($conn->query($updateUserQuery) === TRUE) {
        echo "User details updated successfully";
        // Redirect to a confirmation page or any other page after successful update
        // header("Location: confirmation_page.php");
    } else {
        echo "Error updating user details: " . $conn->error;
    }
}

// Close connection
$conn->close();
?>
