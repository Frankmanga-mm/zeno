<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authority Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        #dashboard-content {
            padding: 20px;
        }

        .dashboard-link {
            display: block;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
        }

        .dashboard-link:hover {
            background-color: #e0e0e0;
        }

        .dashboard-link i {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div id="dashboard-content">
        <h1>Authority Dashboard</h1>
        <!-- View permits -->
        <a href="view_permits.php" class="dashboard-link"><i class="fas fa-file-signature"></i> View Permits</a>
        <!-- Manage permits -->
        <a href="manage_permits.php" class="dashboard-link"><i class="fas fa-tasks"></i> Manage Permits</a>
        <!-- Verify project details -->
        <a href="verify_project_details.php" class="dashboard-link"><i class="fas fa-check-circle"></i> Verify Project Details</a>
        <!-- View compliance status -->
        <a href="compliance_status.php" class="dashboard-link"><i class="fas fa-check-square"></i> Compliance Status</a>
        <!-- Communication -->
        <a href="communicate.php" class="dashboard-link"><i class="fas fa-comments"></i> Communicate</a>
        <!-- Logout -->
        <a href="logout.php" class="dashboard-link"><i class="fas fa-sign-out-alt"></i> Logout</a>

    </div>
</body>
</html>
