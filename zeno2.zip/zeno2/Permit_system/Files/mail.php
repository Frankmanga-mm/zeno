<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-weight: bold;
        }
        input[type="email"] {
            width: 100%;
            padding: 8px;
            margin-top: 4px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .btn {
            background-color: blue;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="text-align: center;">Password Reset</h2>
        <form method="post">
            <div class="form-group">
                <label for="email">Enter your email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <input type="submit" name="submit" value="Send Reset Link" class="btn" style="width: 100%;">
        </form>
        <p style="text-align: center; margin-top: 20px;"><a href="login.php" style="color: blue ;">Back to Login</a></p>
    </div>

    <?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer-master/src/PHPMailer.php';
    require 'PHPMailer-master/src/SMTP.php';
    require 'PHPMailer-master/src/Exception.php';

    include "connection.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
        $email = $_POST['email'];

        // Check if email exists in users table and retrieve username
        $sql = "SELECT username FROM users WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $username = $row['username'];

            $mail = new PHPMailer(true); // Set true for exceptions

            try {
                //Server settings for Gmail SMTP
                $mail->SMTPDebug = SMTP::DEBUG_OFF; // Set to SMTP::DEBUG_SERVER for debugging
                $mail->isSMTP(); // Set mailer to use SMTP
                $mail->Host = 'smtp.gmail.com'; // SMTP server
                $mail->SMTPAuth = true; // Enable SMTP authentication
                $mail->Username = 'mangafrank20@gmail.com'; // SMTP username
                $mail->Password = 'avcf wzkt cbby hukt'; // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption
                $mail->Port = 587; // TCP port to connect to

                //Recipients
                $mail->setFrom('mangafrank20@gmail.com', 'Permit System');
                $mail->addAddress($email); // Add recipient email

                //Content
                $mail->isHTML(true); // Set email format to HTML
                $mail->Subject = 'Password Reset';
                $resetLink = 'http://localhost/permit_system/Files/newPassword.php?email=' . urlencode($email);
                $mail->Body = "Hello $username,<br><br>This is a link to reset your password: <a href='$resetLink'>$resetLink</a>";

                $mail->send();
                echo '<p style="color: green; text-align: center;">Message has been sent. Check your email for the reset link.</p>';
            } catch (Exception $e) {
                echo '<p style="color: red; text-align: center;">Message could not be sent. Mailer Error: ' . $mail->ErrorInfo . '</p>';
            }
        } else {
            echo '<p style="color: red; text-align: center;">Email not found in database</p>';
        }
    }
    ?>
</body>
</html>
