<?php
// Start a PHP session
session_start();

// Include the database connection file
include 'connection.php';

// Initialize variables for user data
$userName = $userEmail = $userPhone = $userAddress = '';
$updateMessage = '';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Retrieve user data from the Users table
    $userQuery = "SELECT username, email FROM Users WHERE user_id = $userId";
    $userResult = mysqli_query($conn, $userQuery);

    if ($userResult && mysqli_num_rows($userResult) > 0) {
        $userData = mysqli_fetch_assoc($userResult);
        $userName = $userData['username'];
        $userEmail = $userData['email'];
    } else {
        $errorMessage = "Error fetching user data.";
    }

    // Retrieve phone and address data from the Owners table
    $ownerQuery = "SELECT contact_number, address, owner_name FROM Owners WHERE user_id = $userId";
    $ownerResult = mysqli_query($conn, $ownerQuery);

    if ($ownerResult && mysqli_num_rows($ownerResult) > 0) {
        $ownerData = mysqli_fetch_assoc($ownerResult);
        $userPhone = $ownerData['contact_number'];
        $userAddress = $ownerData['address'];
    } else {
        $errorMessage = "Error fetching owner data.";
    }

    // Handle form submission to update user details
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
        $newUserName = $_POST['username'];
        $newUserEmail = $_POST['email'];
        $newUserPhone = $_POST['contact_number'];
        $newUserAddress = $_POST['address'];

        // Update user details in the Users table
        $updateUserQuery = "UPDATE Users SET username = '$newUserName', email = '$newUserEmail' WHERE user_id = $userId";
        $updateUserResult = mysqli_query($conn, $updateUserQuery);

        // Update phone and address in the Owners table
        $updateOwnerQuery = "UPDATE Owners SET contact_number = '$newUserPhone', address = '$newUserAddress', owner_name = '$newUserName' WHERE user_id = $userId";
        $updateOwnerResult = mysqli_query($conn, $updateOwnerQuery);

        if ($updateUserResult && $updateOwnerResult) {
            $updateMessage = "User details updated successfully.";
            // Update the displayed user details after successful update
            $userName = $newUserName;
            $userEmail = $newUserEmail;
            $userPhone = $newUserPhone;
            $userAddress = $newUserAddress;
            
            // Redirect to user_dashboard.php after 3 seconds
            echo '<script>
                setTimeout(function() {
                    window.location.href = "user_dashboard.php";
                }, 3000);
            </script>';
        } else {
            $updateMessage = "Error updating user details: " . mysqli_error($conn);
        }
    }
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Close the database connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative; /* Ensure relative positioning for icon placement */
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"] {
            width: calc(100% - 40px); /* Adjust width for icon */
            padding: 8px 10px; /* Adjust padding for icon placement */
            border: 1px solid #ccc;
            border-radius: 5px;
            padding-left: 40px; /* Space for icon */
        }

        .icon {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            left: 10px;
            pointer-events: none; /* Ensure the icon doesn't interfere with input */
            color: #999; /* Adjust icon color */
        }

        button[type="submit"] {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            font-style: italic;
        }

        .update-message {
            color: green;
            font-weight: bold;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Details</h1>
        <?php if (isset($errorMessage)) : ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php else : ?>
            <form method="post">
                <div class="form-group">
                    <label for="username"><i class="fas fa-user icon"></i> Name</label>
                    <input type="text" id="username" name="username" value="<?php echo $userName; ?>">
                </div>
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope icon"></i> Email</label>
                    <input type="email" id="email" name="email" value="<?php echo $userEmail; ?>">
                </div>
                <div class="form-group">
                    <label for="phone"><i class="fas fa-phone icon"></i> Phone</label>
                    <input type="text" id="phone" name="contact_number" value="<?php echo $userPhone; ?>">
                </div>
                <div class="form-group">
                    <label for="address"><i class="fas fa-map-marker-alt icon"></i> Address</label>
                    <input type="text" id="address" name="address" value="<?php echo $userAddress; ?>">
                </div>
                <button type="submit" name="update">Update</button>
            </form>
            <?php if (!empty($updateMessage)) : ?>
                <p><?php echo $updateMessage; ?></p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>
