<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Registration</title>
    <link rel="stylesheet" href="../css/project.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
       
    </style>
</head>

<body>
    <div class="container">
        <h2>Project Registration</h2>
        <form id="projectForm" method="POST">
            <div class="form-group">
                <label for="project_name">Project Name:</label>
                <input type="text" id="project_name" name="project_name" required>
                <i class="fas fa-tasks icon"></i>
            </div>
            <div class="form-group">
                <label for="project_description">Project Description:</label>
                <textarea id="project_description" name="project_description" rows="4"></textarea>
                <i class="fas fa-info-circle icon"></i>
            </div>
            <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date">
                <i class="far fa-calendar-alt icon"></i>
            </div>
            <div class="form-group">
                <label for="completion_date">Completion Date:</label>
                <input type="date" id="completion_date" name="completion_date">
                <i class="far fa-calendar-check icon"></i>
            </div>
            <div class="form-group">
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                </select>
                <i class="fas fa-check-circle icon"></i>
            </div>
            <button type="submit" class="btn">Register Project</button>
        </form>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</body>

</html>
<?php
// Start the session
session_start();

// Include database connection code
include_once "connection.php";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape and sanitize inputs
    $project_name = mysqli_real_escape_string($conn, $_POST['project_name']);
    $project_description = mysqli_real_escape_string($conn, $_POST['project_description']);
    $start_date = $_POST['start_date'];
    $completion_date = $_POST['completion_date'];
    $status = $_POST['status'];

    // Get owner_id from session
    if (isset($_SESSION['owner_id'])) {
        $owner_id = $_SESSION['owner_id'];

        // Prepare and execute the SQL statement
        $sql = "INSERT INTO Projects (owner_id, project_name, project_description, start_date, completion_date, status) 
                VALUES ('$owner_id', '$project_name', '$project_description', '$start_date', '$completion_date', '$status')";
        if (mysqli_query($conn, $sql)) {
            echo "Project registered successfully!";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Owner ID not found in session.";
    }
}
?>
