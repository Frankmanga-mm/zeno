<?php
// Start a PHP session
session_start();

// Include the database connection file
include 'connection.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Retrieve data from the Owners and Documents tables
    $query = "SELECT o.owner_name, d.status
              FROM Owners o
              LEFT JOIN Documents d ON o.owner_id = d.owner_id
              WHERE o.user_id = $userId"; // Use the session user ID

    $result = mysqli_query($conn, $query);

    // Check if the query was successful
    if ($result) {
        // Check if any rows were returned
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $ownerName = $row['owner_name']; // Retrieve owner's name
            $status = $row['status']; // Retrieve the status from Documents table
        } else {
            $errorMessage = "No data found for the user.";
        }
    } else {
        // Handle the error if the query fails
        $errorMessage = "Error fetching data: " . mysqli_error($conn);
    }
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <!-- Include FontAwesome library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-JYydR3au0P6ydAqWbR08eId7cfeMXLWUBXG0l0TcSGLlUtX+CMUT3Hs5Us9bC2iWde3YhSFi8Rp10y9I8gO8VQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-info {
            margin-bottom: 10px;
        }

        .profile-info strong {
            display: inline-block;
            width: 120px;
            font-weight: bold;
        }

        .error-message {
            color: red;
            font-style: italic;
        }

        p {
            margin: 10px 0;
        }

        .back-button {
            display: block;
            width: 120px;
            margin: 20px auto;
            padding: 10px;
            text-align: center;
            background-color: #007bff; /* Blue color */
            color: #fff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }

        .back-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }

        .status-icon {
            margin-left: 10px;
            font-size: 20px;
        }

        .status-icon.approved {
            color: green; /* Green color for approved status */
        }

        .status-icon.pending {
            color: yellow; /* Yellow color for pending status */
        }

        .status-icon.rejected {
            color: red; /* Red color for rejected status */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Status</h1>
        <?php if (isset($errorMessage)) : ?>
            <p class="error-message"><?php echo $errorMessage; ?></p>
        <?php else : ?>
            <div class="profile-info">
                <strong>Name</strong>
                <span><?php echo $ownerName; ?></span>
            </div>
            <div class="profile-info">
                <strong>Status</strong>
                <span><?php echo $status; ?></span>
                <?php
                // Display status icons based on the status value
                if ($status == 'approved') {
                    echo '<i class="fas fa-check-circle status-icon approved"></i>';
                } elseif ($status == 'pending') {
                    echo '<i class="fas fa-clock status-icon pending"></i>';
                } elseif ($status == 'rejected') {
                    echo '<i class="fas fa-times-circle status-icon rejected"></i>';
                }
                ?>
            </div>
            <a href="user_dashboard.php?user_id=<?php echo $userId; ?>" class="back-button">Back to Dashboard</a>
        <?php endif; ?>
    </div>
</body>
</html>
