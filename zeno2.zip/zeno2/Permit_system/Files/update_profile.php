<?php
// Start a PHP session
session_start();

// Include the database connection file
include 'connection.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Retrieve data from the Users and Owners tables
    $query = "SELECT u.username, u.email, o.contact_number, o.address
              FROM Users u
              LEFT JOIN Owners o ON u.user_id = o.user_id
              WHERE u.user_id = $userId"; // Use the session user ID

    $result = mysqli_query($conn, $query);

    // Check if the query was successful
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $username = $row['username'];
        $email = $row['email'];
        $contactNumber = $row['contact_number'];
        $address = $row['address'];
    } else {
        // Handle the error if the query fails
        $errorMessage = "Error fetching data: " . mysqli_error($conn);
    }
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
</head>
<body>
    <h1>User Profile</h1>
    <?php if (isset($errorMessage)) : ?>
        <p><?php echo $errorMessage; ?></p>
    <?php else : ?>
        <p><strong>Username:</strong> <?php echo $username; ?></p>
        <p><strong>Email:</strong> <?php echo $email; ?></p>
        <p><strong>Contact Number:</strong> <?php echo $contactNumber; ?></p>
        <p><strong>Address:</strong> <?php echo $address; ?></p>
    <?php endif; ?>
</body>
</html>
