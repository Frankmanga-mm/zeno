<?php
session_start();

// Include database connection
require_once "connection.php";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user details based on session ID
$userId = $_SESSION['user_id'];
$sql = "SELECT username, email FROM users WHERE user_id = $userId";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            margin-bottom: 20px;
        }

        .profile-link {
            cursor: pointer;
            color: #fff;
            text-decoration: underline;
            margin-right: 20px;
        }

        .user-details {
            display: none;
            background-color: #fff;
            color: #000;
            padding: 10px;
            border-radius: 5px;
            margin-top: 10px;
        }

        .show-details {
            display: block;
        }

        .dashboard-column {
            flex: 0 0 48%;
        }

        .dashboard-link {
            display: block;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
        }

        .dashboard-link:hover {
            background-color: #e0e0e0;
        }

        .dashboard-link i {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="dashboard-header">
        <h1 style="flex-grow: 1; text-align: center;">Dashboard</h1>
        <div class="profile-link" onclick="toggleDetails()">Profile</div>
    </div>
    <div class="user-details" id="userDetails">
        <span><strong>Name:</strong> <?php echo $user['username']; ?></span><br>
        <span><strong>Email:</strong> <?php echo $user['email']; ?></span>
    </div>
    <div id="dashboard-content" style="display: flex;">
        <div class="dashboard-column">
            <!-- Left Column Content -->
            <!-- Account management -->
            <a href="owner_details_registration.php" class="dashboard-link"><i class="fas fa-user-plus"></i> Owner Details Registration</a>
            <a href="apply_permit.php?user_id=<?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : ''; ?>" class="dashboard-link">
                <i class="fas fa-file-signature"></i> Apply Permit
            </a>
            <a href="user_profile.php" class="dashboard-link"><i class="fas fa-user"></i> Profile</a>
            <a href="change_password.php" class="dashboard-link"><i class="fas fa-lock"></i> Change Password</a>
            <!-- View notifications and alerts -->
            <a href="notifications.php" class="dashboard-link"><i class="fas fa-bell"></i> View Notifications</a>
        </div>
        <div class="dashboard-column">
            <!-- Right Column Content -->
            <!-- Access help or support -->
            <a href="user_update.php" class="dashboard-link"><i class="fas fa-plus-circle"></i> Update Your details</a>
            <!-- View project status -->
            <a href="status.php" class="dashboard-link"><i class="fas fa-chart-bar"></i> Status</a>
            <!-- Access documents and permits -->
            <a href="view_documents.php?user_id=<?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : ''; ?>" class="dashboard-link"><i class="fas fa-file-alt"></i> View Documents</a>

            <a href="Print_permits.php" class="dashboard-link"><i class="fas fa-stamp"></i> Print Permits</a>
            <!-- View permit details -->
            <a href="view_permit_details.php" class="dashboard-link"><i class="fas fa-eye"></i> View Permit Details</a>
            <!-- Logout -->
            <a href="logout.php" class="dashboard-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>

    <script>
        function toggleDetails() {
            var userDetails = document.getElementById("userDetails");
            userDetails.classList.toggle("show-details");
        }
    </script>
</body>

</html>
