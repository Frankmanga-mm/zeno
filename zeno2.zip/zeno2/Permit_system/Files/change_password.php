



<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    require_once "connection.php";

    // Get user input
    $prevPassword = $_POST["prevPassword"];
    $newPassword = $_POST["newPassword"];
    $confirmPassword = $_POST["confirmPassword"];

    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
    // Check if new password matches confirm password
    if ($newPassword !== $confirmPassword) {
        $_SESSION["message"] = "New password and confirm password do not match.";
        header("Location: change_password.php");
        exit();
    }

    // Get user's previous password hash from the database
    $userId = $_SESSION["user_id"]; 
    echo"$userId";
    // Assuming you have stored user ID in session
    $sql = "SELECT password_hash FROM users WHERE user_id = $userId";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $storedPassword = $row["password_hash"]; // Corrected variable name

        // Verify if the previous password matches
        if (password_verify($prevPassword, $storedPassword)) {
            // Hash the new password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update the password hash in the database
            $updateSql = "UPDATE users SET password_hash = '$hashedPassword' WHERE user_id = $userId"; // Corrected column name
            if (mysqli_query($conn, $updateSql)) {
                $_SESSION["message"] = "Password changed successfully.";
                header("Location: login.php");
                exit();
            } else {
                $_SESSION["message"] = "Error updating password. Please try again.";
                header("Location: change_password.php");
                exit();
            }
        } else {
            $_SESSION["message"] = "Incorrect previous password.";
            header("Location: change_password.php");
            exit();
        }
    } 
    
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .error {
            color: #f00;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Change Password</h2>
        <form action="" method="POST">
            <label for="prevPassword">Previous Password:</label>
            <input type="password" id="prevPassword" name="prevPassword" required>

            <label for="newPassword">New Password:</label>
            <input type="password" id="newPassword" name="newPassword" required>

            <label for="confirmPassword">Confirm New Password:</label>
            <input type="password" id="confirmPassword" name="confirmPassword" required>

            <input type="submit" value="Change Password">
        </form>
        <?php
        if (isset($_SESSION["message"])) {
            echo '<div class="error">' . $_SESSION["message"] . '</div>';
            unset($_SESSION["message"]);
        }
        ?>
    </div>
</body>
</html>

   