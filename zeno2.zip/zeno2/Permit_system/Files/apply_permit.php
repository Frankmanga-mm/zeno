

<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection code here
    include "connection.php"; // Change this to your actual database connection file
    
    // Get user_id from the URL query parameter using GET method
    $user_id = isset($_GET['user_id']) ? $_GET['user_id'] : '';
    echo"$user_id";
    // Query the owners table to get the owner_id corresponding to the user_id
    $owner_id_query = "SELECT owner_id FROM owners WHERE user_id = $user_id";
    $result = mysqli_query($conn, $owner_id_query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $owner_id = $row['owner_id'];
        echo"$owner_id";
        // Get other form data
        $document_name = $_POST["document_name"];
        $document_type = $_POST["document_type"];
        
        // File upload handling
        $target_directory = "../uploads/";
        $target_file = $target_directory . basename($_FILES["upload_file"]["name"]);
        $uploadOk = 1;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        if ($_FILES["upload_file"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        
        if ($file_type != "pdf" && $file_type != "doc" && $file_type != "docx" && $file_type != "txt") {
            echo "Sorry, only PDF, DOC, DOCX, and TXT files are allowed.";
            $uploadOk = 0;
        }
        
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            if (move_uploaded_file($_FILES["upload_file"]["tmp_name"], $target_file)) {
                // Insert data into the documents table
                $query = "INSERT INTO documents (owner_id, document_name, document_type, file_path) 
                          VALUES ('$owner_id', '$document_name', '$document_type', '$target_file')";
                if (mysqli_query($conn, $query)) {
                    echo "New record inserted successfully.";
                } else {
                    echo "Error: " . $query . "<br>" . mysqli_error($conn);
                }
            } else {
                echo "Sorry, there was an error uploading your file. Error code: " . $_FILES["upload_file"]["error"];
            }
        }
    } else {
        echo "Error: Owner not found for user ID $user_id";
    }
}
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Permit</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }

        .permit-form {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="file"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .form-group select {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        .required-icon::before {
            content: '*';
            color: red;
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
        }

        .btn-submit {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="permit-form">
        <h2>Apply for Permit</h2>
        <form  method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="document_name" class="required-icon">Document description</label>
                <input type="text" id="document_name" name="document_name" required>
            </div>
            <div class="form-group">
                <label for="document_type" class="required-icon">Select document Type</label>
                <select id="document_type" name="document_type" required>
                    <option value=""></option>
                    <option value="Building Permit">Building Permit</option>
                    <option value="Environmental Permit">Environmental Permit</option>
                    <option value="Zoning Permit">Zoning Permit</option>
                    <!-- Add more options as needed -->
                </select>
            </div>
            <div class="form-group">
                <label for="upload_file" class="required-icon">Upload Document</label>
                <input type="file" id="upload_file" name="upload_file" accept=".pdf,.doc,.docx,.txt" required>
            </div>
            <button type="submit" class="btn-submit">Submit</button>
        </form>
    </div>
</body>

</html>
