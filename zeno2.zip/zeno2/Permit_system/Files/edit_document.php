<?php
// Start a PHP session
session_start();

// Include the database connection file
include 'connection.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Check if document ID is provided in the URL
    if (isset($_GET['document_id'])) {
        $documentId = $_GET['document_id'];

        // Retrieve the specific document for the user
        $query = "SELECT d.document_id, d.document_name, d.document_type, d.upload_date, d.file_path 
                  FROM Documents d
                  INNER JOIN Owners o ON d.owner_id = o.owner_id
                  WHERE d.document_id = $documentId AND o.user_id = $userId";
        $result = mysqli_query($conn, $query);

        // Check if the query was successful and document exists
        if ($result && mysqli_num_rows($result) > 0) {
            $document = mysqli_fetch_assoc($result);
            // Fetch document details
            $documentName = $document['document_name'];
            $documentType = $document['document_type'];
            $uploadDate = $document['upload_date'];
        } else {
            // Document not found or not authorized
            echo "Document not found or you don't have permission to edit.";
            exit(); // Stop further execution
        }
    } else {
        // No document ID provided in the URL
        echo "Document ID is required.";
        exit(); // Stop further execution
    }
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Check if the form is submitted for updating the document
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_document'])) {
    $documentId = $_POST['document_id']; // Retrieve document ID from the form
    $documentName = $_POST['document_name'];
    $documentType = $_POST['document_type'];
    $uploadDate = $_POST['upload_date'];

    // Update the document details in the database
    $updateQuery = "UPDATE Documents 
                    SET document_name = '$documentName', document_type = '$documentType', upload_date = '$uploadDate' 
                    WHERE document_id = $documentId";
    $updateResult = mysqli_query($conn, $updateQuery);

    if ($updateResult) {
        echo "Document updated successfully.";
    } else {
        echo "Error updating document: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 20px;
        }

        .form-container h2 {
            margin-bottom: 20px;
        }

        .form-container label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .form-container input[type="text"],
        .form-container input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .form-container button {
            padding: 8px 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit Document</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="document_id" value="<?php echo $documentId; ?>">
            <label for="document_name">Document Name:</label>
            <input type="text" id="document_name" name="document_name" value="<?php echo $documentName; ?>" required>
            <label for="document_type">Document Type:</label>
            <input type="text" id="document_type" name="document_type" value="<?php echo $documentType; ?>" required>
            <label for="upload_date">Upload Date:</label>
            <input type="text" id="upload_date" name="upload_date" value="<?php echo $uploadDate; ?>" required>
            <button type="submit" name="update_document">Update Document</button>
        </form>
    </div>
</body>
</html>
