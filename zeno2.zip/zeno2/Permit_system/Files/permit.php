<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Permit Application Form</title>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
    }
    .container {
        max-width: 600px;
        margin: 0 auto;
    }
    .form-group {
        margin-bottom: 15px;
    }
    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }
    input[type="text"],
    input[type="date"],
    select {
        width: 100%;
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>
<div class="container">
    <h2>Permit Application Form</h2>
    <form id="permitForm"  method="POST">
        <div class="form-group">
            <label for="permitType">Permit Type:</label>
            <select name="permit_type" id="permitType" required>
                <option value=""></option>
                <option value="Building Permit">Building Permit</option>
                <option value="Environmental Permit">Environmental Permit</option>
                <!-- Add more options as needed -->
            </select>
        </div>
        <div class="form-group">
            <label for="permitNumber">Permit Number:</label>
            <input type="text" id="permitNumber" name="permit_number" required>
        </div>
        <div class="form-group">
            <label for="issueDate">Issue Date:</label>
            <input type="date" id="issueDate" name="issue_date" required>
        </div>
        <div class="form-group">
            <label for="expiryDate">Expiry Date:</label>
            <input type="date" id="expiryDate" name="expiry_date" required>
        </div>
        <input type="submit" value="Submit Permit Application">
    </form>
</div>
</body>
</html>


<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "_permit_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted and the permit type is selected
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['permit_type'])) {
  // Escape user inputs for security
  $permitType = $conn->real_escape_string($_POST['permit_type']);
  $permitNumber = $conn->real_escape_string($_POST['permit_number']);
  $issueDate = $conn->real_escape_string($_POST['issue_date']);
  $expiryDate = $conn->real_escape_string($_POST['expiry_date']);

  // Get owner_id from the query string or form submission
  $owner_id = isset($_GET['owner_id']) ? $conn->real_escape_string($_GET['owner_id']) : '';

  // Check if owner_id is not empty
  if (!empty($owner_id)) {
    // Query to get the document_type associated with the owner_id
    $docQuery = "SELECT document_type FROM documents WHERE owner_id = $owner_id";
    $docResult = $conn->query($docQuery);

    // Check if a document_type was retrieved
    if ($docResult->num_rows > 0) {
      $row = $docResult->fetch_assoc();
      $document_type = $row['document_type'];

      // Compare the selected permit type with the retrieved document_type
      if ($permitType == $document_type) {
        // Insert data into permits table
        $sql = "INSERT INTO Permits (owner_id, permit_type, permit_number, issue_date, expiry_date) VALUES ('$owner_id', '$permitType', '$permitNumber', '$issueDate', '$expiryDate')";

        if ($conn->query($sql) === TRUE) {
          // Update document status to 'approved'
          $update = "UPDATE documents SET status = 'approved' WHERE owner_id = $owner_id";

          if ($conn->query($update) === TRUE) {
            echo "New record created successfully";
          } else {
            echo "Failed to update status";
          }
        } else {
          echo "Error inserting data: " . $conn->error;
        }
      } else {
        echo "Error: Selected permit type does not match the one applied by the customer.";
      }
    } else {
      echo "No document found for owner ID: " . $owner_id;
    }
  } else {
    echo "Owner ID not provided.";
  }
}

// Close connection
$conn->close();
?>
