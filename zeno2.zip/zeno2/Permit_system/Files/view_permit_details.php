<?php
// Start a PHP session
session_start();

// Include the database connection file
include 'connection.php';

// Initialize variables for user data
$userName = $ownerName = $areaName = $contactNumber = $address = $permitType = $permitNumber = $issueDate = $expiryDate = '';
$errorMessage = '';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Retrieve username from Users table
    $userQuery = "SELECT username FROM Users WHERE user_id = $userId";
    $userResult = mysqli_query($conn, $userQuery);

    if ($userResult && mysqli_num_rows($userResult) > 0) {
        $userData = mysqli_fetch_assoc($userResult);
        $userName = $userData['username'];
    } else {
        $errorMessage = "Error fetching username: " . mysqli_error($conn);
    }

    // Retrieve owner details from Owners table
    $ownerQuery = "SELECT owner_name, area_name, contact_number, address FROM Owners WHERE user_id = $userId";
    $ownerResult = mysqli_query($conn, $ownerQuery);

    if ($ownerResult && mysqli_num_rows($ownerResult) > 0) {
        $ownerData = mysqli_fetch_assoc($ownerResult);
        $ownerName = $ownerData['owner_name'];
        $areaName = $ownerData['area_name'];
        $contactNumber = $ownerData['contact_number'];
        $address = $ownerData['address'];
    } else {
        $errorMessage = "Error fetching owner details: " . mysqli_error($conn);
    }

    // Retrieve permit details from Permit table
    $permitQuery = "SELECT permit_type, permit_number, issue_date, expiry_date FROM Permits WHERE owner_id = (SELECT owner_id FROM Owners WHERE user_id = $userId)";
    $permitResult = mysqli_query($conn, $permitQuery);

    if ($permitResult && mysqli_num_rows($permitResult) > 0) {
        $permitData = mysqli_fetch_assoc($permitResult);
        $permitType = $permitData['permit_type'];
        $permitNumber = $permitData['permit_number'];
        $issueDate = $permitData['issue_date'];
        $expiryDate = $permitData['expiry_date'];
    } else {
        $errorMessage = "Error fetching permit details: " . mysqli_error($conn);
    }

    // Generate the letter format
    $letter = "Dear $userName,\nwith phone number $contactNumber\nthe owner of the area $areaName at $address\nYou have given a  $permitType with permit number $permitNumber \nfrom  $issueDate up to $expiryDate\n\nSincerely,\n[Your Name]";
} else {
    // No user ID found in session
    $errorMessage = "No user ID found in session.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
        }

        .letter {
            white-space: pre-wrap;
            font-family: Arial, sans-serif;
            font-size: 14px;
        }

        .back-button {
            margin-top: 20px;
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff; /* Blue color */
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }

        .back-button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>
</head>

<body>
    <div class="container">
        <?php if (!empty($errorMessage)) : ?>
            <div class="error-message"><?php echo $errorMessage; ?></div>
        <?php else : ?>
            <div class="letter">
                <?php echo $letter; ?>
            </div>
            <a href="user_dashboard.php?user_id=<?php echo $userId; ?>" class="back-button">Back to Dashboard</a>
        <?php endif; ?>
    </div>
</body>

</html>
