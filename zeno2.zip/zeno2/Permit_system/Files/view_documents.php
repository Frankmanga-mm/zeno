<?php
// Start a PHP session
session_start();

// Include the database connection file
include 'connection.php';

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Retrieve all documents for the user
    $query = "SELECT d.document_id, d.document_name, d.document_type, d.upload_date, d.file_path 
              FROM Documents d
              INNER JOIN Owners o ON d.owner_id = o.owner_id
              WHERE o.user_id = $userId";
    $result = mysqli_query($conn, $query);

    // Check if the query was successful
    if ($result && mysqli_num_rows($result) > 0) {
        // Fetch and display the documents
        while ($row = mysqli_fetch_assoc($result)) {
            $documentId = $row['document_id'];
            $documentName = $row['document_name'];
            $documentType = $row['document_type'];
            $uploadDate = $row['upload_date'];
            $filePath = $row['file_path'];

            // Display the document details
            echo "<div class='document'>";
            echo "<p><strong>Document Name:</strong> $documentName</p>";
            echo "<p><strong>Document Type:</strong> $documentType</p>";
            echo "<p><strong>Upload Date:</strong> $uploadDate</p>";
            echo "<p><strong>File Path:</strong> <a href='$filePath' target='_blank'>$filePath</a></p>";
            echo "<button class='edit-button' data-documentid='$documentId' data-filepath='$filePath'>Edit</button>";
            echo "</div>";
        }
    } else {
        // No documents found
        echo "No documents found.";
    }
} else {
    // Redirect to the login page if the user is not logged in
    header("Location: login.php");
    exit();
}

// Close the database connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Documents</title>
    <!-- Add your CSS styles here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        .document {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #fff;
        }

        .document p {
            margin: 5px 0;
        }

        .document a {
            color: #007bff;
            text-decoration: none;
        }

        .edit-button {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            margin-top: 5px;
        }

        .edit-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- PHP code for document retrieval goes here -->

    <script>
        // JavaScript for editing documents
        document.querySelectorAll('.edit-button').forEach(button => {
            button.addEventListener('click', () => {
                const documentId = button.getAttribute('data-documentid');
                const filePath = button.getAttribute('data-filepath');
                // Redirect to edit_document.php with document ID and file path
                window.location.href = `edit_document.php?document_id=${documentId}&filepath=${encodeURIComponent(filePath)}`;
            });
        });
    </script>
</body>
</html>
